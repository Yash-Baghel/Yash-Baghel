
# Assignment 1 — Mini E‑Commerce (Flask + SQLite)

## Run (VS Code)
1) Open this folder in VS Code.
2) Create a Python venv, activate it, and install:
   ```bash
   pip install -r requirements.txt
   ```
3) Initialize DB (first run is automatic). To force:
   ```bash
   python db_init.py
   ```
4) Start server:
   ```bash
   python app.py
   ```
5) Open http://localhost:5000

## Notes
- API: `GET /api/products`, `POST /api/order` with body `{items: [{id, qty}]}`.
- This project creates and edits multiple files. Use VS Code "Inline Chat" to tweak `app.py`, `db_init.py`, and `static/*` simultaneously.
