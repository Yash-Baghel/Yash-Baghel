
const productsEl = document.getElementById('products');
const cartEl = document.getElementById('cart');
const checkoutBtn = document.getElementById('checkout');
const checkoutResultEl = document.getElementById('checkout-result');

const state = { products: [], cart: {} };

async function loadProducts() {
  const res = await fetch('/api/products');
  state.products = await res.json();
  renderProducts();
}

function addToCart(id) {
  state.cart[id] = (state.cart[id] || 0) + 1;
  renderCart();
}

function renderProducts() {
  productsEl.innerHTML = state.products.map(p => `
    <div class="card">
      <h3>${p.name}</h3>
      <p>₹${p.price.toFixed(2)}</p>
      <p>Stock: ${p.stock}</p>
      <button onclick="addToCart(${p.id})">Add to Cart</button>
    </div>
  `).join('');
}

function renderCart() {
  const entries = Object.entries(state.cart);
  if (!entries.length) { cartEl.innerHTML = '<i>Cart is empty</i>'; return; }
  let html = '<ul>';
  for (const [id, qty] of entries) {
    const p = state.products.find(x => x.id == id);
    html += `<li>${p?.name || id} × ${qty}</li>`;
  }
  html += '</ul>';
  cartEl.innerHTML = html;
}

checkoutBtn.addEventListener('click', async () => {
  const items = Object.entries(state.cart).map(([id, qty]) => ({id: Number(id), qty}));
  if (!items.length) { checkoutResultEl.textContent = 'Cart is empty'; return; }
  const res = await fetch('/api/order', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({items})
  });
  const data = await res.json();
  if (res.ok) {
    checkoutResultEl.textContent = `Order #${data.order_id} placed. Total ₹${data.total}`;
    state.cart = {};
    renderCart();
    await loadProducts();
  } else {
    checkoutResultEl.textContent = data.error || 'Checkout failed';
  }
});

loadProducts();
