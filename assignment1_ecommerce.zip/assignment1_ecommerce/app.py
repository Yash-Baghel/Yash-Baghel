
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import sqlite3, os, json, time

DB_PATH = os.path.join(os.path.dirname(__file__), "ecom.db")

def get_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

app = Flask(__name__, static_folder="static", template_folder="static")
CORS(app)

@app.route("/")
def index():
    return send_from_directory("static", "index.html")

@app.route("/api/products", methods=["GET"])
def products():
    con = get_db()
    rows = con.execute("SELECT id, name, price, stock FROM products").fetchall()
    data = [dict(r) for r in rows]
    return jsonify(data)

@app.route("/api/order", methods=["POST"])
def order():
    payload = request.json or {}
    items = payload.get("items", [])
    if not isinstance(items, list) or not items:
        return jsonify({"error": "No items provided"}), 400

    con = get_db()
    cur = con.cursor()

    # Check stock
    for it in items:
        pid = int(it.get("id", -1))
        qty = int(it.get("qty", 0))
        row = cur.execute("SELECT stock, price FROM products WHERE id=?", (pid,)).fetchone()
        if not row:
            return jsonify({"error": f"Product {pid} not found"}), 404
        if row["stock"] < qty:
            return jsonify({"error": f"Insufficient stock for product {pid}"}), 400

    # Create order
    ts = int(time.time())
    cur.execute("INSERT INTO orders(created_at) VALUES(?)", (ts,))
    order_id = cur.lastrowid

    total = 0.0
    for it in items:
        pid = int(it["id"]); qty = int(it["qty"])
        row = cur.execute("SELECT price FROM products WHERE id=?", (pid,)).fetchone()
        price = float(row["price"])
        total += price * qty
        cur.execute("INSERT INTO order_items(order_id, product_id, qty, price) VALUES(?,?,?,?)",
                    (order_id, pid, qty, price))
        # decrement stock
        cur.execute("UPDATE products SET stock = stock - ? WHERE id=?", (qty, pid))

    con.commit()
    return jsonify({"order_id": order_id, "total": round(total, 2)}), 201

if __name__ == "__main__":
    # Helpful default: create DB if missing
    if not os.path.exists(DB_PATH):
        import db_init
        db_init.init_db(DB_PATH)
    app.run(host="0.0.0.0", port=5000, debug=True)
