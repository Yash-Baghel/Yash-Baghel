
import sqlite3, os

PRODUCTS = [
    ("Wireless Mouse", 799.0, 25),
    ("Mechanical Keyboard", 3499.0, 15),
    ("USB-C Hub", 1599.0, 30),
    ("HD Webcam", 2599.0, 20),
    ("Laptop Stand", 1299.0, 40),
    ("Noise-Cancelling Headphones", 5999.0, 10),
]

def init_db(db_path="ecom.db"):
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.executescript(
        '''
        DROP TABLE IF EXISTS order_items;
        DROP TABLE IF EXISTS orders;
        DROP TABLE IF EXISTS products;
        CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            stock INTEGER NOT NULL
        );
        CREATE TABLE orders(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at INTEGER NOT NULL
        );
        CREATE TABLE order_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            qty INTEGER NOT NULL,
            price REAL NOT NULL,
            FOREIGN KEY(order_id) REFERENCES orders(id),
            FOREIGN KEY(product_id) REFERENCES products(id)
        );
        '''
    )
    cur.executemany("INSERT INTO products(name, price, stock) VALUES(?,?,?)", PRODUCTS)
    con.commit()
    con.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized and seeded.")
